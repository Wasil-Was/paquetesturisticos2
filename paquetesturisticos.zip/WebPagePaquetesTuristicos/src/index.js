var bodyParser = require ('body-parser');
const express = require ('express');
const path = require ('path');
const app = express();
const conn = require('./ConnectBD');

//CONFIGURACIÓN INICIAL
app.set('port',process.env.PORT || 3000);


//VISTA:
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'view/pages'));
//Acceso Público a la carpeta 'images' y 'css'
app.use('/images', express.static(path.join(__dirname, 'view/images')));
app.use('/styles', express.static(path.join(__dirname, 'view/styles')));


//MIDDLEWARE (Lógica de Intercambio de Información.)
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true})); //Analiza el texto como URL


//RUTAS (Rutas de datos e información.)
app.use('/', require('./routes/all'));


//SERVIDOR
app.listen(app.get('port'), () => {
    console.log('Servidor en Puerto',app.get('port'))
});