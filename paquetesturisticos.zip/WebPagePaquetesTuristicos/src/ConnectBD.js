const mysql = require('mysql2');

let con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'wasil',
    database: 'paquetesturisticos',
    port: 3306
});

con.connect(function (err){
    if(err){
        console.log(err);
        console.log('\nDB NOT CONNECTED.')
        return;
    }
    else{
        console.log('DB CONNECTED.')
    }
});

module.exports = con;